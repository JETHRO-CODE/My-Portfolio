<!DOCTYPE html>
<html lang="en">
<?php require "includes/header1.php"; ?>
<body>
<?php require "includes/header2.php"; ?>
<div class="title">BLOG</div>
<div class="main_container_blog">

    <div class="main_body">
    <h1>What Our Users Are Saying</h1>

    <div class="change">
      <p></p>
      <h4></h4>
    </div>

</div>
</div>

     <?php include "includes/footer.php"; ?>

     <script src="javascripts/script1.js"></script>
</body>
</html>