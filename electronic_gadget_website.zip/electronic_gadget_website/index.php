<!DOCTYPE html>
<html lang="en">
<?php require "includes/header1.php"; ?>
<body>
<?php require "includes/header2.php"; ?>

    <div class="slider_container">
<figure>
    <img src="images/slider/download.jpg" alt="">
    <img src="images/slider/download 1.jpg" alt="">
    <img src="images/slider/Laptop 6.jpeg" alt="">
    <img src="images/slider/download 3.jpg" alt="">
</figure>

    </div>
    <div class="homepage_container">
        <div class="product_container_home">
            <div class="product">
            <a href="product.php"><img src="images/product/IMG-20220419-WA0101.jpg" alt=""></a>
                <h4>Laptop</h4>
            </div>
            <div class="product">
            <a href="product.php"><img src="images/product/IMG-20220419-WA0096.jpg" alt=""></a>
                <h4>Phones</h4>
            </div>
            <div class="product">
            <a href="product.php"><img src="images/product/IMG-20220419-WA0095.jpg" alt=""></a>
                <h4>Airpod</h4>
            </div>
            <div class="product">
            <a href="product.php"><img src="images/product/IMG-20220419-WA0106 (3).jpg" alt=""></a>
                <h4>Wrist Watch</h4>
            </div>
        </div>
        <a href="product.php"><button type="submit" class="product_button">More products</button></a>
    </div>



   <div class="floating_image">
       <div class="floating_picture"><img src="images/Laptop 6.jpeg" height="250px" width="300px"></div>
       <div class="floating_text"><h4>As mentioned earlier, <em>KENTRO TECHNOLOGIES LTD</em> is the most tested and trusted place to buy your laptops,phones and other devices. <br>
       <br> We are verified on a lot of gadgets such as Laptops, Phones, Tablets.Smart Watches etc. Again, we are always active and ready to give you the best gadgets at reasonable prices.<br><br> Our rates are the best.</h4></div>
   </div>
  
   <div class="content">u <br><br>a
   <p class="head"> <small>KENTRO TECHNOLOGIES LTD OFFERS THE BEST PRICES ON GADGETS!</small></p>
   <h1 class="head">How To Buy Or ORDER FOR GADGETS In Nigeria</h1></div>
   <div class="testimonials">
          <div class="text"><p>
              <h2>ORDER ONLINE OR COME TO OUR OUTLETS</h2>
                        </p>
        </div>

          <div class="text">
          <p>
              <h2>MAKE AN ORDER OR MAKE PAYMENT AT ANY OF OUR OUTLETS</h2>
                       </p>
          </div>

          <div class="text">
          <p>
              <h2>Get YOUR MONEY WORTH</h2>
                        </p>
          </div>
    </div>



   <div class="why">
       <h2>WHY KENTRO TECHNOLOGIES LTD?</h2>
</div>
       <div class="why_trade">
          <div class="why_trade1">
             <div><h4>ORDER</h4></div> 
          <div><p>We deliver easily and quickly.</p></div>
          </div>

          <div class="why_trade1">
          <div><h4>QUALITY PRODUCTS</h4></div>
          <div><p>We deliver good, durable efficient products that brings out your moneys worth.</p></div>
          </div>

          <div class="why_trade1">
          <div><h4>Good Service</h4></div>
              <div><p>Our services includes buying,selling and exchange of electronic gadgets.</p></div>
          </div>
        </div>
       


    <div class="questions">
     <div><h2> Learn more <span class="learn_more"> about KENTRO TECHNOLOGIES LTD </span>   <button class="button"><h4>READ OUR BLOG</h4></button></h2></div>
    </div>
    
     <?php include "includes/footer.php"; ?>

   
</body>
</html>