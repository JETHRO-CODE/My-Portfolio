<div class="footer">
         <div class="footer1">
             <div class="footer_column">
                 <h3>KENTRO TECHNOLOGIES LTD</h3>
                 <p class="p">KENTRO TECHNOLOGIES LTD delivers swift, excellent service that meets and exceeds the service expectations of her esteemed clients with lightening speed to maximise client satisfaction.</p> 
             </div>

             <div class="footer_column">
             <h3>CONTACT INFO</h3>
                 <p class="p">Office Phone: (234) 090-38951421<br>
                 Coustomer service: (234) 090-76831515 <br>
                 Email: <a href="https://mail.google.com/mail/u/0/#inbox?compose=CllgCKCFTSqNHGsxdzMvpxJLRHNRxWsZfxBqsGqTFSdLvgvsZgkjdpzwlwZqlQJwrCJDrplGGSq">omoladejethro7@gmail.com</a><br>
                
                </p> 
             </div>

             <div class="footer_column">
             <h3>SERVICE HOURS</h3>
                 <p class="p">Monday - Sunday: 08:00AM - 09:00PM
                   For hours beyond 9pm and Weekends:call (234) 9038951421</p>
             </div>

             <div class="footer_column">
             <h3>SOCIALS</h3>
                 <pre>
                     <p class="p"><a href="https://wa.me/+2349038951421"><i class="fa-brands fa-whatsapp fa-3x fa-color"></i></a>  <a href="https://www.instagram.com/ KENTRO TECHNOLOGIES LTD?r=nametag"><i class="fa-brands fa-instagram fa-3x fa-color1"></i></a>   <a href="https://twitter.com/KENTRO TECHNOLOGIES LTD__Explorer?t=cyyDb3v5aH5yEgRjqQ3agA&s=09"><i class="fa-brands fa-twitter fa-3x fa-color2"></i></a></p>
             </div>

         </div>
     <div class="footer2"><span>All Rights REserved &copy;2022 Designed By <a href="https://morrhtechsolutions.com/">Morrhtech Solutions</a></span></div>

     </div>

     <script src="javascripts/jquery.js"></script>
  <script src="javascripts/script1.js"></script>