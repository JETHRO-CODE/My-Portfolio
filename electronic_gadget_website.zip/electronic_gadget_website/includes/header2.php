<div class="top_bar_container">
   <span class="email"><i class="fa-regular fa-envelope"></i> Omoladejethro7@gmail.com</span>   <span class="number"><span class="hide_phone"><i class="fa-solid fa-phone"></i>+234 9038951421</span>      <a href="https://wa.me/+2349033246432"><i class="fa-brands fa-whatsapp fa-color"></i></a>  <a href="https://www.instagram.com/c_hub.exchange?r=nametag">
   <i class="fa-brands fa-instagram fa-color1"></i></a>   <a href="https://twitter.com/C_HUB__Explorer?t=cyyDb3v5aH5yEgRjqQ3agA&s=09"><i class="fa-brands fa-twitter fa-color2"></i></a></span></p>
   <span class="social_icons"><a href="https://wa.me/+2349038951421"><i class="fa-brands fa-whatsapp fa-color"></i></a>  <a href="https://www.instagram.com/c_hub.exchange?r=nametag"><i class="fa-brands fa-instagram fa-color1"></i></a>   <a href="https://twitter.com/C_HUB__Explorer?t=cyyDb3v5aH5yEgRjqQ3agA&s=09"><i class="fa-brands fa-twitter fa-color2"></i></a></span>

</div>
    <div class="header_container">
   <div class="logo_container">
   <a href="index.php"><img src="images/Laptop 6.jpeg" alt=""></a>
   </div>

   <ul class="menu_item">
       <li><a href="index.php"><i class="fa-solid fa-house"></i>Home</a></li>
       <li><a href="about_us.php"><i class="fa-solid fa-address-card"></i>About Us</a></li>
       <li><a href="product.php"><i class="fa-brands fa-product-hunt"></i>Product</a></li>
       <li><a href="blog.php"><i class="fa-brands fa-blogger"></i>Blog</a></li>
       <li><a href="contact_us.php"><i class="fa-solid fa-address-book"></i>Contact Us</a></li>
   </ul>

<div class="hamburger" id="hamburger_menu">
      <div class="line"></div>
      <div class="line"></div>
     <div class="line"></div>
 </div>

 <ul class="dropdown_item" id="dropdown_menu">
       <li><a href="index.php"><i class="fa-solid fa-house"></i>Home</a></li>
       <li><a href="about_us.php"><i class="fa-solid fa-address-card"></i>About Us</a></li>
       <li><a href="product.php"><i class="fa-brands fa-product-hunt"></i>Product</a></li>
       <li><a href="blog.php"><i class="fa-brands fa-blogger"></i>Blog</a></li>
       <li><a href="contact_us.php"><i class="fa-solid fa-address-book"></i>Contact Us</a></li>
   </ul>
    </div>