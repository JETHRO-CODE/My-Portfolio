<!DOCTYPE html>
<html lang="en">
<?php require "includes/header1.php"; ?>
<body>
<?php require "includes/header2.php"; ?>
<div class="title"><h2>About Us</h2></div>
<div class="main_container1">

    <div class="main_body1">
        
   <div class="head1"><h1>About Us</h1></div>
   <div class="our_mission_container">
<div class="our_mission"><h2><img src="https://previews.123rf.com/images/basel101658/basel1016581111/basel101658111100119/11349829-vector-light-bulb-on-black-background.jpg" >Our Mission</h2>
<p>To establish the most secure place to easily get your electronic gadgets.</p>
</div>
<div class="our_mission"><h2><img src="https://previews.123rf.com/images/basel101658/basel1016581111/basel101658111100119/11349829-vector-light-bulb-on-black-background.jpg" >Our Vision</h2>
<p>To become the Biggest place globaly where people can buy their electronic gadgets.</p>
</div>
</div>
</div>
</div>

     <?php include "includes/footer.php"; ?>
     <script src="javascripts/script1.js"></script>
</body>
</html>