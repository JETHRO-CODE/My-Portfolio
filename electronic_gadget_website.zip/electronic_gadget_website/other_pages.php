<!DOCTYPE html>
<html lang="en">
<?php require "includes/header1.php"; ?>
<body>
<?php require "includes/header2.php"; ?>
<div class="title">TITLE</div>
<div class="main_container">
    <div class="side_bar">
    <div class="product">
                <img src="images/product/BITCOIN.jpg" alt="">
                <h4>Bitcoin</h4>
            </div>
            <div class="product">
                <img src="images/product/Binance coin.webp" alt="">
                <h4>BNB</h4>
            </div>
            <div class="product">
                <img src="images/eth.png" alt="">
                <h4>Etherieum</h4>
            </div>

    </div>
    <div class="main_body">Content</div>
</div>
     <?php include "includes/footer.php"; ?>

</body>
</html>