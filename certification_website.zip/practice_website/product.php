<!DOCTYPE html>
<html lang="en">
<?php require "includes/header1.php"; ?>
<body>
<?php require "includes/header2.php"; ?>
<div class="title">Our Product</div>

<div class="services"><br><br><br><br>
         <span class="text_head">Our Services</span>
         <h1 class="h1">We offer expert skincare solutions</h1><br>
         <p class="LHS_text1">Dodo white skincare product offers garanteed solutions to all skin related problems. Our creams have just the exact formular you need to achive a light, spotless and healthy with all shades of perfection.</p><br>
</div>  

<div class="Contact_info">
          <div class="contact_items1">
          <img src="images/item.jpeg" height="400px" width="450px">
          </div>

          <div class="contact_items1">
          <img src="images/item2.jpeg" height="400px" width="450px">
          </div>

          <div class="contact_items1">
          <img src="images/item3.jpeg" height="400px" width="450px">
          </div>
        </div>   

     <?php include "includes/footer.php"; ?>

    
</body>
</html>