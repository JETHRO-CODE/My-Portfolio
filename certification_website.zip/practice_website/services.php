<!DOCTYPE html>
<html lang="en">
<?php require "includes/header1.php"; ?>
<body>
<?php require "includes/header2.php"; ?>
<div class="title">Services</div>

<!-- Blog Items -->
<div class="blog_items">
<div class="main_content">

         <div class="contents">
          <img src="images/slider/blog-1.jpg" alt="" height="400px"><br>
          <div><h1>Insert Any Text Of Your Choice</h1></div>
          </div>
          <div class="contents">
          <img src="images/slider/blog-1.jpg" alt="" height="400px"><br>
          <div><h1>Insert Any Text Of Your Choice</h1></div>
          </div>
          <div class="contents">
          <img src="images/slider/blog-1.jpg" alt="" height="400px"><br>
          <div><h1>Insert Any Text Of Your Choice</h1></div>
          </div>
          <div class="contents">
          <img src="images/slider/blog-1.jpg" alt="" height="400px"><br>
          <div><h1>Insert Any Text Of Your Choice</h1></div>
          </div>
</div>





<!-- Left-Hand-Side Categories -->
<div class="categories_section">
<div class="Categories_heading"><h2>Special Dodo white Purposes</h2></div>
<div class="categories">
             <div><p><i class="fa-solid fa-angle-right fa-color4"></i>Black Spot Removal</p></div>
          </div>
          <div class="categories">
             <div><p><i class="fa-solid fa-angle-right fa-color4"></i>Anti-aging Lotion</p></div>
          </div>
          <div class="categories">
             <div><p><i class="fa-solid fa-angle-right fa-color4"></i>Body lightening</p></div>
          </div>
          <div class="categories">
             <div><p><i class="fa-solid fa-angle-right fa-color4"></i>Skin tone for dark skin</p></div>
          </div>
</div>
</div>


     <?php include "includes/footer.php"; ?>

   
</body>
</html>