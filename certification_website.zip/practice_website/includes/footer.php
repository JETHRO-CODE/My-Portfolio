<div class="footer">
         <div class="footer1">
             <div class="footer_column">
                 <h3>G.Don mega business Limited</h3><br>
                 <p class="p">Dodo white skin care company will br more than glad to attend to your skin solution requests.</p><br>
                 <a href=""><i class="fa-brands fa-whatsapp fa-2x"></i></a>
                 <a href=""><i class="fa-brands fa-facebook fa-2x"></i></a>
                 <a href=""><i class="fa-brands fa-linkedin fa-2x"></i></a>
                 <a href=""><i class="fa-brands fa-instagram fa-2x"></i></a>
             </div>
.
             <div class="footer_column">
             <h3>Quick Links</h3><br>
             <ul class="list_style">
                 <li><p class="WHY_CHOOSE_US_Ponts"><i class="fa-solid fa-angle-right fa-color4"></i>Home</p></li>
                 <li><p class="WHY_CHOOSE_US_Ponts"><i class="fa-solid fa-angle-right fa-color4"></i>About Us</p></li>
                 <li> <p class="WHY_CHOOSE_US_Ponts"><i class="fa-solid fa-angle-right fa-color4"></i>Services</p></li>
                 <li>  <p class="WHY_CHOOSE_US_Ponts"><i class="fa-solid fa-angle-right fa-color4"></i>Product</p></li>
                 <li>   <p class="WHY_CHOOSE_US_Ponts"><i class="fa-solid fa-angle-right fa-color4"></i>Contact Us</p> </li>
             </ul>     
             </div>

             <div class="footer_column">
             <h3>Popular Links</h3><br>
             <ul class="list_style">
                 <li><p class="WHY_CHOOSE_US_Ponts"><i class="fa-solid fa-angle-right fa-color4"></i>Home</p></li>
                 <li><p class="WHY_CHOOSE_US_Ponts"><i class="fa-solid fa-angle-right fa-color4"></i>About Us</p></li>
                 <li> <p class="WHY_CHOOSE_US_Ponts"><i class="fa-solid fa-angle-right fa-color4"></i>Services</p></li>
                 <li>  <p class="WHY_CHOOSE_US_Ponts"><i class="fa-solid fa-angle-right fa-color4"></i>Product</p></li>
                 <li>   <p class="WHY_CHOOSE_US_Ponts"><i class="fa-solid fa-angle-right fa-color4"></i>Contact Us</p> </li>
             </ul>   
            </div>

             <div class="footer_column">
             <h3><a href="contact_us.php">Get in Touch</a></h3><br>
                 <p>Our services are open to clients teenty four hours everyday. for further inquires:</p>
                 <p class="WHY_CHOOSE_US_Ponts"><i class="fa-solid fa-location-dot fa-color4"></i>NASSIA Complex Ojo, Badagry expressway ,Lagos</p>
                 <p class="WHY_CHOOSE_US_Ponts"><i class="fa-solid fa-phone fa-color4"></i>&#43; 234 90 6117 8207</p>
                 <p class="WHY_CHOOSE_US_Ponts"><i class="fa-solid fa-envelope fa-color4"></i>info@gdonmegabusinesslimited.com</p> 
             </div>

         </div>
     <div class="footer2"><span>All Rights Reserved &copy;2022 Designed By <a href="https://chubexchange.com/">C-HUB EXCHANGE</a></span></div>

     </div>
dz..
     <script src="javascripts/jquery.js"></script>
     <script src="javascripts/script1.js"></script>
     