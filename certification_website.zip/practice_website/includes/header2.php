
    <div class="header_container">
   <div class="logo_container">
   <a href="index.php"><img src="images/C-hub.png" alt=""></a>
   </div>

   <ul class="menu_item">
       <li><a href="index.php">Home</a></li>
       <li><a href="about_us.php">About Us</a></li>
       <li><a href="services.php">Services</a></li>
       <li><a href="product.php">Our Product</a></li>
       <li><a href="contact_us.php">Contact Us</a></li>
   </ul>

<div class="hamburger" id="hamburger_menu">
      <div class="line"></div>
      <div class="line"></div>
     <div class="line"></div>
 </div>

 <ul class="dropdown_item" id="dropdown_menu">
       <li><a href="index.php">Home</a></li>
       <li><a href="about_us.php">About Us</a></li>
       <li><a href="services.php"></i>Services</a></li>
       <li><a href="product.php">Our Product</a></li>
       <li><a href="contact_us.php">Contact Us</a></li>
   </ul>
    </div>