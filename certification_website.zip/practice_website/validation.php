<!DOCTYPE html>
<html lang="en">
<?php require "includes/header1.php"; ?>
<body>
<div class="Thank_you_container">
    <div class="thankyou_div">
<h1 class="thanks_heading">Thank You For Contacting Us</h1><br><br><br>
<h3>Kindly Chat Us Up On Whatsapp<p class="WHY_CHOOSE_US_Ponts"><a href=""><i class="fa-brands fa-whatsapp fa-2x"></i></a>&#43; 234 90 6117 8207</p></h3>
<div class="nothing">ihefqoqf <br></div>
</div>
</div>






</body>
</html>