<!DOCTYPE html>
<html lang="en">
<?php require "includes/header1.php"; ?>
<body>
<?php require "includes/header2.php"; ?>
<div class="title"><h2>About Us</h2></div>

<div class="floating_image">
       <div class="floating_picture"><img src="images/item.jpeg" height="460px" width="550px"></div>
       <div class="floating_text"><span class="floating_text1">Exciting Facts About Us</span>
       <h1 class="floating_text_header">Spotless Skin Solution Saver</h1><br>
       <p>Dodo white with carrot extract is a product naturally developed by veterans in the field of beauty and skin care, who have carefully picked out the best ingredient to solve all skin related problems without causing physical or health damages for our happy clients.</p>
    </div>
  
    </div>

<div class="main_container1">

    <div class="main_body1">
        
   
   <div class="our_mission_container">
<div class="our_mission"><h2><img src="https://previews.123rf.com/images/basel101658/basel1016581111/basel101658111100119/11349829-vector-light-bulb-on-black-background.jpg" >Our Mission</h2>
<p>To save our highly valued clients from all challenges, costs and disappointment caused by skin types, skin infections and reactions with the aid of Dodo white cream product.</p>
</div>
<div class="our_mission"><h2><img src="https://previews.123rf.com/images/basel101658/basel1016581111/basel101658111100119/11349829-vector-light-bulb-on-black-background.jpg" >Our Vision</h2>
<p>"A smooth, clear and healthy skin makes a happy client". At Dodo white, our primary vision is to do all within our professional experience towards ensuring that Dodo white skin care cream product reaches more happy clients globally.</p>
</div>
</div>
</div>
</div>

     <?php include "includes/footer.php"; ?>
     <script src="javascripts/script1.js"></script>
</body>
</html>